from flask import Flask
from flask_restful import  Api
from flask_jwt import JWT

from security import authenticate, identity
from resources.user import UserRegister
from resources.item import Item, Itemlist

app = Flask(__name__)
app.secret_key = 'jose'
api = Api(app)
jwt = JWT(app,authenticate,identity) #/auth

#pip3.6 freeze
#pip3.6 install virtualenv
#virtualenv venv --python=python3.6
#source venv/bin/activate
#python --version
#pip3.6 freeze
#pip install flask
#pip freeze
#pip install Flask-RESTful
#pip install Flask-JWT
#./venv/Scripts/Activate.bat       --- window OS

api.add_resource(Itemlist,'/items') # http://27.0.0.1:5000/
api.add_resource(Item,'/item/<string:name>') # http://27.0.0.1:5000/item/<name>
api.add_resource(UserRegister, '/register')

if __name__ == '__main__':
    app.run(port=5000,debug=True)
