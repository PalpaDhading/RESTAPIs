#virtualenv venv --python=python3.6
#source venv/bin/activate
#./venv/Scripts/activate.bat
#pip freeze
#-------------------------
#pip install flask
#pip install Flask

#pip install Flask-JWT
#pip install Flask-RESTful
#pip install Flask-SQLAlchemy
#-------------------------
(venv) Yashnas-MBP:section6 Murari$ pip freeze
aniso8601==1.3.0
click==6.7
Flask==0.12.2
Flask-JWT==0.3.2
Flask-RESTful==0.3.6
Flask-SQLAlchemy==2.3.2
itsdangerous==0.24
Jinja2==2.10
MarkupSafe==1.0
PyJWT==1.4.2
python-dateutil==2.6.1
pytz==2017.3
six==1.11.0
SQLAlchemy==1.2.0
Werkzeug==0.14
(venv) Yashnas-MBP:section6 Murari$
#cp ../section5/code/* code/
#rm code/data.db
